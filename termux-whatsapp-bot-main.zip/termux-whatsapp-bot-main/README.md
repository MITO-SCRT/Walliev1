
<P align="center">
    <img alt="Im Lexa" src ="https://user-images.githubusercontent.com/72728486/108575146-e06e5280-734b-11eb-9268-b91b09e8b374.gif" width="180"

</P>

<p align="center">
<a href="https://github.com/mrfzvx12"><img title="mrfzvx12" src="https://img.shields.io/badge/github-Mrfzvx12-orange.svg?style=social&logo=github"></a>
</p>
<p align="center">
<img src="https://gpvc.arturio.dev/mrfzvx12" />
<a href="https://github.com/mrfzvx12"><img title="Author" src="https://img.shields.io/badge/Termux Whatsapp Bot-V2-orange?style=for-the-badge&logo=github"></a>
<a href="https://github.com/mrfzvx12/followers"><img title="Followers" src="https://img.shields.io/github/followers/mrfzvx12?label=Followers&style=social"></a>
<a href="https://github.com/mrfzvx12/im-lexa-v2/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/mrfzvx12/termux-whatsapp-bot?&style=social"></a>
<a href="https://github.com/mrfzvx12/im-lexa-v2/network/members"><img title="Fork" src="https://img.shields.io/github/forks/mrfzvx12/termux-whatsapp-bot?style=social"></a>
<a href="https://github.com/mrfzvx12/im-lexa-v2/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/mrfzvx12/termux-whatsapp-bot?label=Watching&style=social"></a>
<a href="https://github.com/mrfzvx12/im-lexa-v2/watchers"><img title="Contributor" src="https://img.shields.io/github/contributors/mrfzvx12/termux-whatsapp-bot?logo=github&style=social"></a>
</p>
<p align="center">
<a href="https://github.com/mrfzvx12/im-lexa-v2"><img src="https://img.shields.io/github/repo-size/mrfzvx12/im-lexa-v2?label=Repo%20size&style=plastic"></a>
<a href="https://github.com/mrfzvx12/im-lexa-v2"><img src="https://img.shields.io/github/search/mrfzvx12/termux-whatsapp-bot/termux-whatsapp-bot?label=Search&style=plastic"></a>
</p>

# Lest begin's
* Klik stars agar bisa terus update
* Klik watch agar dapat notifikasi ketika update
* Semua fitur work tergantung api dan apikey

### Tes bot
Sebelum menginstal Lexa V.2 coba dulu botnya disini
<p>
<a href="https://chat.whatsapp.com/FQNUK5VFD68GZaB0UlXjst" target="blank"><img src="https://img.shields.io/badge/Grup Whatsapp 1-30302f?style=flat&logo=whatsapp" /></a>
<a href="https://chat.whatsapp.com/CxAPJ6En3uSDqDX1mmBvrv" target="blank"><img src="https://img.shields.io/badge/Grup Whatsapp 2-30302f?style=flat&logo=whatsapp" /></a>
</p>

### Tools
| Aplikasi | Link |
|--------|--------|
| **Termux** | [Download disini](https://play.google.com/store/apps/details?id=com.termux) |
| **Acode** | [Download disini](https://play.google.com/store/apps/details?id=com.foxdebug.acodefree) |
<p align="center">
  <div align="center">
 <code><img height="40" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/terminal/terminal.png"></code>
 <code><img height="40" src="https://user-images.githubusercontent.com/72728486/108440991-c9196180-7286-11eb-910e-d95691565ec8.png"></code>

  </div>
  </p>


### Install With Termux

```bash
> git clone https://github.com/mrfzvx12/termux-whatsapp-bot
> cd termux-whatsapp-bot
> bash install.sh
> npm start
```

### Setting
* DATA BOT

Tempat : ```./data/setting```

Contoh default :
```
{
	"prefix": ".",
	"ownerNumber": "6282223014661",
	"BarBarKey": "YourApiKey",
	"Vhtearkey": "YourApiKey",
	"LolHumanKey": "YourApiKey",
        "Vinzapi": "Yourapikey",
        "Itsmeikyapi": "Yourapikey",
	"limit": "20",
  "memberlimit": "20",
  "cr": "𝗠𝗮𝗱𝗲 𝗪𝗶𝘁𝗵 ❤️",
  "hargalimit": "500",
  "NamaBot": "Lexa V.2",
  "Ig": "http://www.instagram.com/mrf.zvx/",
  "Wa1": "https://chat.whatsapp.com/FQNUK5VFD68GZaB0UlXjst",
  "Wa2": "https://chat.whatsapp.com/CxAPJ6En3uSDqDX1mmBvrv",
  "Ovo": "082223014661",
  "Pulsa": "082223014661",
  "Dana": "082223014661"
}
```

* Kontak owner

Tempat : ```./index.js/101```

Contoh default :

```
const vcard = 'BEGIN:VCARD\n'
+ 'VERSION:3.0\n'
+ 'FN:Mrf.zvx\n' // Nama
+ 'ORG:Lexa bot;\n' // Nama bot
+ 'TEL;type=CELL;type=VOICE;waid=6282223014661:+62 822-2301-4661\n' // Nomor owner
+ 'END:VCARD' 
```

### Let's connect with me
<p>
<a href="http://wa.me/6282223014661" target="blank"><img src="https://img.shields.io/badge/Whatsapp-30302f?style=flat&logo=whatsapp" /></a>
<a href="http://www.instagram.com/mrf.zvx/" target="blank"><img src="https://img.shields.io/badge/Instagram-30302f?style=flat&logo=instagram" /></a>
<a href="https://www.facebook.com/profile.php?id=100028409167054" target="blank"><img src="https://img.shields.io/badge/Facebook-30302f?style=flat&logo=facebook" /></a>
</p>
